﻿using System;
using System.Collections.Generic;
using System.Text;

namespace _1._Generic_Box_of_String
{
    internal class Box
    {
    }
}
