﻿using System;

namespace DefiningClasses
{
    public class StartUp
    {
        static void Main()
        {
            string name=Console.ReadLine();
            int age=int.Parse(Console.ReadLine());
            Person person = new Person(name, age);

        }
    }
}
