﻿using System;
using System.Collections.Generic;
using System.Text;

namespace _1._Library
{
    internal class Library
    {
    }
}
